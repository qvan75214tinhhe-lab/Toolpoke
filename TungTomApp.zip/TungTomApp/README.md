# TungTom APK

App Android (WebView) chạy userscript **TungTom v1.11.0** cho pokesurvivor.com / pokesurvivor.doofcraft.com.
Menu điều khiển nằm trong app (nút 🍤 kéo được ở góc màn hình) thay cho bảng trong trang.

## Build APK
**Cách 1 – GitHub Actions (không cần máy tính):** tạo repo GitHub, upload toàn bộ thư mục này
(giữ nguyên `.github/`), vào tab *Actions* → *Build APK* → tải artifact `TungTom-apk`.

**Cách 2 – Android Studio:** Open thư mục này → Build → Build APK(s) → `app/build/outputs/apk/debug/`.

## Khung thu nhỏ trang
Menu 🍤 → mục **Khung thu nhỏ trang**: bật một khung nhỏ (kéo được) vẽ lại trang đơn giản hơn: canvas game thu nhỏ,
cùng nút/chữ/ảnh của HUD vẽ thành khối màu. Chỉnh được kích thước, kiểu vẽ (thu nhỏ / ít màu), nội dung
(toàn trang / chỉ canvas game) và tốc độ cập nhật (3/6/12 khung/giây). Mã nằm trong `assets/bridge.js`.

## Cập nhật script
Chép đè `app/src/main/assets/TungTom_user.js` rồi build lại.

## Lưu ý
- Userscript được tiêm ở document-start (giống Via/Tampermonkey), nên hook game hoạt động như bản gốc.
- Nút "Xuất data.js" (tải file) của bảng F6 không dùng được trong WebView; phím F6–F9 cũng không có trên điện thoại.
- Gốc: damhieu2808/PokeSurvivorTool (MIT).
